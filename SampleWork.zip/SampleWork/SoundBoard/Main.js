/**
 * @author Bartosz Zych
 * Started 31.10.17 - 09:30
 * Finished 
 * 
 */



/**
 * main entry to the game
 */
function main()
{

    var soundManager = new SoundManager();
    soundManager.init();

    var sounds = {
        'fart': 'Sounds/fart.mp3',
        'hi': 'Sounds/hi.mp3',
        'bro': 'Sounds/bro.mp3',
        'hi bro': 'Sounds/hi bro.mp3'
    };

    soundManager.loadSoundFile("fart", "Sounds/fart.mp3");
    soundManager.loadSoundFile("hi", "Sounds/hi.mp3")
    soundManager.loadSoundFile("bro", "Sounds/bro.mp3")
    soundManager.loadSoundFile("hi there", "Sounds/hi there.mp3")

    //for (var i in sounds)
    //{
    //    if (sounds.hasOwnProperty(i))
    //    {
    //        soundManager.loadSoundFile(sounds[i].name, sounds[i].value)
    //    }
    //}

    //creating div
    createDiv("fart",soundManager,1);
    createDiv("hi", soundManager,1);
    createDiv("bro", soundManager,1);
    createDiv("hi there", soundManager,0);
    createDiv("hi there", soundManager, 2);
   

}

function createDiv(divId, soundManager,volume)
{
    var div = document.createElement("div");
    div.id = divId;
    div.innerHTML = divId;
    div.classList.add("myButton");
    document.body.appendChild(div);
    var tapped = false;
    var looping = false;
    div.addEventListener("touchstart", function (e)
    {

        if (looping)
        {
            soundManager.stop();
        }
        if (!tapped)
        {
            tapped = setTimeout(function () {
                tapped = null;
                if (!looping) {
                    soundManager.playSound(divId, false,volume);
                }
                looping = false;
            }, 400);//wait 400 milliseconds before running single click code
        }
        else 
        {
            clearTimeout(tapped);
            tapped = null;
            looping = true;
            soundManager.playSound(divId, true, volume);
        }
    });
}






