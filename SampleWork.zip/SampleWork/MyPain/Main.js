/**
 * @author Bartosz Zych
 * Started 24.10.17 - 09:05
 * Finished 
 * 
 */


/**
 * main entry to the game
 */

var xEnd, yEnd, xStart, yStart,initailX,initialY;
function main()
{
    initCanvas(); 
    var ctx;
    var time1;
    var time2;
}

/**
 * On touch event which starts time of the touch
 * and sets x and y values
 * @param {Event} e
 */
function onTouchStart(e)
{
    var touches = e.touches;
   
    xStart = touches[0].clientX;
    yStart = touches[0].clientY;
    initailX = touches[0].clientX;
    initailY = touches[0].clientY;
    time1 = new Date();
}
/**
 * On the move event keep set the keep a point
  *set another and keep drawing between them
 * @param {Event} e
 */
function onTouchMove(e)
{
    var touches = e.touches
    var length = touches.length;

    

    xEnd = touches[0].clientX;
    yEnd = touches[0].clientY;

    ctx.beginPath();
    ctx.moveTo(xStart, yStart);	//the previous touch
    ctx.lineTo(xEnd, yEnd);	//the current touch
    ctx.stroke();
    xStart = touches[0].clientX;
    yStart = touches[0].clientY;

   
}

/**
 * Calculate time of between 2 events start and end
 * calculate length between initial touch and final touch
 * display length time taken and swiped messege
 * @param {Event} e
 */
function onTouchEnd(e)
{
    time2 = new Date();
   


   
    // sqrt((x2-x1)2 + (y2-y1)2) = length
    length = Math.sqrt(((xEnd - initailX) * (xEnd - initailX)) + ((yEnd - initailY) * (yEnd - initailY)));
   
    finalTime = time2 - time1;

    if (finalTime < 200 && length > 100)
    {
        console.log(finalTime);
        console.log(length);
        console.log("Swiped");
    }

}


/**
* Initialises the canvas - the drawing surface. The canvas
* is added to the document. When a HTML document is loaded into a
* browser, it becomes a document object. This document object is
* the root node of the HTML document and is considered the 'owner' of all other
* nodes such as forms, buttons, the canvas etc.
*/
function initCanvas()
{
    // Use the document object to create a new element canvas.
    this.canvas = document.createElement("canvas");
    // Assign the canvas an id so we can reference it elsewhere.
    this.canvas.id = 'mycanvas';
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    this.levelComplete = "Level Complete";

    //Touch event listeners
    document.addEventListener("touchstart", onTouchStart);
    document.addEventListener("touchmove", onTouchMove);
    document.addEventListener("touchend", onTouchEnd);

    window.addEventListener("keydown", function (e) {
        // Space and arrow keys
        if ([32, 37, 38, 39, 40].indexOf(e.keyCode) > -1) {
            e.preventDefault();
        }
    }, false);


    // We want this to be a 2D canvas.
    ctx = this.canvas.getContext("2d");
    // Adds the canvas element to the document.
    document.body.appendChild(this.canvas);
}

